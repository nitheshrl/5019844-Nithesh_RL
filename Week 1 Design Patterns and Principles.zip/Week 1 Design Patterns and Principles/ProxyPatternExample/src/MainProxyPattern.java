public class MainProxyPattern {
    public static void main(String[] args) {
        Image image1 = new ProxyImage("download1.jpg");
        Image image2 = new ProxyImage("download2.jpg");

        image1.display();
        System.out.println();
        image2.display();
        System.out.println();

        image1.display();
    }
}