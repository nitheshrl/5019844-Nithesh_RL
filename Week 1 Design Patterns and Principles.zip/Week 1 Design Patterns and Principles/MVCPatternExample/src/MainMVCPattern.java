public class MainMVCPattern {
    public static void main(String[] args) {
        Student model = new Student("Dangu", "8540", "A+");

        StudentView view = new StudentView();

        StudentController controller = new StudentController(model, view);

        controller.updateView();

        controller.updateStudentDetails();

        controller.updateView();
    }
}
