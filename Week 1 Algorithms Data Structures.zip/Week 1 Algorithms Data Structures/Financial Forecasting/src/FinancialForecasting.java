import java.util.Scanner;

public class FinancialForecasting {

    public static double calculateFutureValue(double initialValue, double growthRate, int years) {
        if (years <= 0) {
            return initialValue;
        }
        return calculateFutureValue(initialValue * (1 + growthRate), growthRate, years - 1);
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Initial value: ");
        double initialValue = scanner.nextDouble();

        System.out.print("Growth rate: ");
        double growthRate = scanner.nextDouble() / 100; 

        System.out.print("Years to forecast: ");
        int years = scanner.nextInt();

        double futureValue = calculateFutureValue(initialValue, growthRate, years);
        System.out.println("Future Value: " + futureValue);

        scanner.close();
    }
}