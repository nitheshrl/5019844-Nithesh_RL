package com.library.LibrarymanagementSystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LibrarymanagementSystem {

	public static void main(String[] args) {
		SpringApplication.run(LibrarymanagementSystem.class, args);
	}

}
