package com.library.LibrarymanagementSystemFull;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibrarymanagementSystem {

	@Test
	void contextLoads() {
	}

}
